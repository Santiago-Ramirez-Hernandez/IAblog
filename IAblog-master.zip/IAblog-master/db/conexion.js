const {Pool} = require('pg');
const dbPassword = process.env.DB_PASSWORD
const configuracion = {
    user: 'postgres',
    host: 'localhost',
    password: dbPassword,
    database: 'blog_IA',
    port: 5432, // Asegúrate de incluir el puerto, 5432 es el predeterminado para PostgreSQL
};

new Pool(configuracion); 
const pool = new Pool(configuracion);

module.exports = pool;