# IAblog
---

Pagina web sobre Inteligencia artificial


## Cuestionarios

El blog cuenta con cuestionarios permiten al usuario medir el conocimiento adquirido durante su estadía en el blog. Cada sección del blog contiene un 
cuestionario.

### Tecnologías

Usaremos la API de **PostGreSQL** para interactuar con la base de datos.
Ejecutar en la terminal el siguiente comando para instalar la dependencia:
```
    npm install pg

    npm install express

    npm install cors
```

### Conexión a Base de Datos

En la carpeta **routes** podremos encontrar el archivo *questionnaries.js* que es el encargado de obtener todos los cuestionarios que se encuentran en la base de datos.


### Direccionamiento a Cuestionario

La pestaña quiz (quiz.html) es responsiva conforme a la página desde la cual es direccionada, por ejemplo, desde distintas partes del sitio web puedes acceder a la misma pestaña quiz pero los datos se cargaran dependiendo del tema en el cual encontraste el botón.

El botón que se encuentra al final de cada parte del sitio web es el siguiente
```html
<article class="botonQuiz">
    <a href="/quiz.html?id=$numeroDelID">
        <button>Pon a prueba tus habilidades</button>
    </a>
</article>
```


---