//--------------Declaración de variables con eleemntos HTML
const quizContainer = document.getElementById("quizContainer");
const quizQuestion = document.getElementById("quizQuestion");
const options = document.getElementsByName("quiz-answer");
let optLabels = []
const opcA = document.getElementById("opcA");
optLabels.push(opcA);
const opcB = document.getElementById("opcB");
optLabels.push(opcB);
const opcC = document.getElementById("opcC");
optLabels.push(opcC);
const opcD = document.getElementById("opcD");
optLabels.push(opcD);

//---------Obtención de datos de la BD
const quiz = {};
//Obtener el id de el cuestionario
const urlParams = new URLSearchParams(window.location.search);
const quizId = urlParams.get('id');

// Función para cargar el cuestionario desde la base de datos usando el ID
async function cargarCuestionario(quizId) {
    try {
        const response = await fetch(`http://localhost:3000/api/questions/${quizId}`);
        if (!response.ok) {
            throw new Error('Error al cargar el cuestionario');
        }
        const quizData = await response.json();
        return quizData;
    } catch (error) {
        console.error('Error al cargar el cuestionario:', error);
    }
}

// Función para formatear los datos en la estructura esperada
function formatQuizData(quizData) {
    return {
        questions: quizData.map((question) => ({
            question: question.questioncontent,
            options: {
                a: question.answers[0].AnswerContent,
                b: question.answers[1].AnswerContent,
                c: question.answers[2].AnswerContent,
                d: question.answers[3].AnswerContent
            },
            answer: question.answers.findIndex(answer => answer.IsCorrect) // Encuentra el índice de la respuesta correcta
        }))
    };
}

// Llamar a la función de carga del cuestionario con el ID que obtuviste de la URL
cargarCuestionario(quizId).then(quizData => {
    quiz = formatQuizData(quizData);
    // Aquí puedes continuar utilizando 'quiz' en las demás funciones
    console.log(quiz);
    // Generar la primera pregunta
    generateQuestion(0);
});


// ------ LOgica de verificacion de datos
const answers = [];

let index = 0;
//Agregar funcionamiento radio Buttons
for (const opt of options) {
    opt.addEventListener('click',saveAnswer);
}

//Agregar logica botones
const submitBtn = document.getElementById("submitBtn");

const lastBtn = document.getElementById("lastBtn");
lastBtn.addEventListener( 'click',
    () => {
        index != 0 ? index-- : console.log("No existe pregunta anterior");
        generateQuestion(index);
        cleanAnswers();
    }
)
const nextBtn = document.getElementById("nextBtn");
nextBtn.addEventListener( 'click',
    () => {
        index != quiz.questions.length-1 ? index++ : console.log("Ultima pregunta");
        generateQuestion(index);
        cleanAnswers();
    }
)

submitBtn.addEventListener('click',testResults);

//Funciones
function cleanAnswers() {
    //Verificar si el usuario ya respondió para conservar la respeusta seleccionada
    if(answers[index] == null){
       options.forEach(opt => {opt.checked = false}); 
    }else{
        options[answers[index]].checked = true;
    }
    
}
function saveAnswer(){
    //Guardar respuesta seleccionada
    let selected = "";
    for(let i= 0; i<=3; i++){
        if (options[i].checked) {
            selected = i;
        }
    }
    if(selected !== ""){
        answers[index] = selected;
    }
}

function generateQuestion(index) {
    quizQuestion.textContent = quiz.questions[index].question;
    opcA.textContent = quiz.questions[index].options.a;
    opcB.textContent = quiz.questions[index].options.b;
    opcC.textContent = quiz.questions[index].options.c;
    opcD.textContent = quiz.questions[index].options.d;
}
function testResults(){
    let counter = 0;
    for (let i = 0; i < quiz.questions.length-1; i++) {
        
        if(answers[i] == quiz.questions[i].answer )
            counter++;
    }
    console.log(counter);
    
}


//Ejecucuión
const timer = setInterval(() =>{
    //Comprobar limite de preguntas para activar o desactivar botones
   if (index == quiz.questions.length-1)
    nextBtn.style.display = "none";
   else
   nextBtn.style.display = "block";

   if (index == 0)
    lastBtn.style.display = "none";
   else
    lastBtn.style.display = "block";
    //Comprobar preguntas respondidas para activar el botón de finalización
    let emptyanswers = 0;
    for (const answer of answers) {
        if (answer == null) {
            emptyanswers +=1;
        }
    }
    if(answers.length == quiz.questions.length && emptyanswers==0)
        submitBtn.disabled = false;
},10);