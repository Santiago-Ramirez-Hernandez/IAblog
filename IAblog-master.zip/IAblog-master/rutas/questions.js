const express = require('express');
const pool = require('../db/conexion');
const router = express.Router();

// Obtener preguntas de un cuestionario específico
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const { rows } = await pool.query('SELECT questionid, questioncontent, score FROM Questions WHERE QuestionnaireID = $1', [id]);
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener preguntas:', error);
        res.status(500).json({ message: 'Error al obtener preguntas' });
    }
});

module.exports = router;
