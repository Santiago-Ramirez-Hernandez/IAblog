const express = require('express');
const pool = require('../db/conexion');
const router = express.Router();

// Ruta para obtener todos los cuestionarios
router.get('/', async (req, res) => {
    try {
        const query = 'SELECT * FROM Questionnaires';
        const result = await pool.query(query); // Ejecutar consulta

        // Imprimir los datos en la consola

        // Enviar los datos como respuesta JSON
        res.json(result.rows); // Enviar los datos al frontend
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Error al obtener los cuestionarios' });
    }
});

module.exports = router;