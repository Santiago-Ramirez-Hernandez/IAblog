const express = require('express');
const pool = require('../db/conexion');
const router = express.Router();

// Ruta para obtener todas las respuestas
router.get('/:questionId', async (req, res) => {
    const { questionId } = req.params;
    try {
        const query = 'SELECT answerid,questionid,answercontent,iscorrect FROM Answers WHERE questionId = $1';
        const result = await pool.query(query, [questionId]); // Pasa la consulta y los parámetros correctamente
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Error al obtener las respuestas' });
    }
});

module.exports = router;